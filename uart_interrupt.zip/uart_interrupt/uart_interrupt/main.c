/*
 * uart_interrupt.c
 *
 * Created: 9/30/2020 9:14:17 PM
 * Author : aki-technical
 */ 

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>
#include <avr/interrupt.h>

void uartInit(unsigned long baud){
	unsigned int UBRR;
	/*Baud rate calculator*/
	UBRR=(F_CPU/(16*baud))-1;
	UBRRH=(unsigned char)(UBRR>>8);
	UBRRL=(unsigned char)UBRR;
	/*Enable the transmitter and receiver with receiver
	complete interrupt*/
	UCSRB=(1<<RXCIE)|(1<<RXEN)|(1<<TXEN);
	/*asynchronous mode, 8-bit, 1-stop bit*/
	UCSRC=(1<<URSEL)|(1<<UCSZ1)|(1<<UCSZ0);
	sei();
}

void uartTransmit(unsigned char data){
	/*Stay here until the buffer is empty*/
	while(!(UCSRA&(1<<UDRE)));
	/*Put the data into the buffer*/
	UDR=data;
}

void uartString(unsigned char *data){
	while(*data) uartTransmit(*data++);
}

char rcvData=0;

int main(void)
{
	DDRC=0xFF;
	uartInit(9600);
	uartString("USART Receiver Interrupt Example.\r");
	while (1)
	{
		PORTC=rcvData;
	}
}

/*Interrupt Vector for the USART*/
ISR(USART_RXC_vect){
	/*Read the data from buffer*/
	rcvData=UDR;
	/*Clear the interrupt flag*/
	UCSRA|=(1<<RXC);
}
