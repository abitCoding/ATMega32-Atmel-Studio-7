/*
 * interfacingToSSD.c
 *
 * Created: 4/26/2020 9:27:54 PM
 * Author : akiTechnical
 */ 

#include <avr/io.h>

#define F_CPU 16000000UL
#include "util/delay.h"

//SET THE INPUT BUTTON FOR COUNTING
#define btnPressed ((PIND&0x01)==0)

int main(void)
{
	//SEVEN SEGMENT MAP FOR COMMON
	//CATHODE TYPE SEVEN SEGMENT DISPLAY
	unsigned char ssd[16]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,
	0x07,0x7F,0x6F,0x77,0x7C,0x39,0x5E,0x79,0x71};
	unsigned char btnCount=0;
	
	DDRC=0xFF;	//PORTC IS FOR OUTPUT TO SEVEN SEGMENT
	DDRD=0xFE;  //PORTD PD0 IS USED FOR INPUT COUNTING
	PORTD=0x01; //SET PD0 TO HIGH FOR PULLING UP
	while (1)
	{
		if (btnPressed) //CHECK IF PD0 IS PRESSED
		{
			btnCount+=1; //Increase The Counter
			_delay_ms(250);
			if(btnCount>15) btnCount=0; //RESET COUNTER WHEN IT IS OVER 15
		}
		PORTC=ssd[btnCount];  //OUTPUT TO SSD
	}
}
