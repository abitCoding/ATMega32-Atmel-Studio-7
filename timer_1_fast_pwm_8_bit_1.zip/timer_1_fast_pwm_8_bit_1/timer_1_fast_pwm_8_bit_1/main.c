/*
 * timer_1_fast_pwm_8_bit_1.c
 *
 * Created: 2/10/2021 3:41:04 PM
 * Author : admin
 */ 

#include <avr/io.h>

int main(void)
{
	/*OC1A PD5 Output*/
	DDRD|=(1<<5);
	/*Non-inverting mode, fast PWM 8-bit*/
	TCCR1A=(1<<COM1A1)|(1<<COM1B1)|(1<<WGM12)|(1<<WGM10);
	/*1:64 Prescaler*/
	TCCR1B=(1<<CS11)|(1<<CS10);
	/*Select 50% duty cycle*/
	OCR1AH=0;
	OCR1AL=127;
    while (1) 
    {
    }
}

