/*
 * Lm35Lcd.c
 *
 * Created: 9/1/2020 9:20:11 AM
 * Author : bonTha
 */ 

#include <avr/io.h>
#include <stdio.h>

#define F_CPU 16000000UL
#include <util/delay.h>

#define lcdPort    PORTD
#define lcdDir     DDRD

#define RS	0
#define E	1

void lcdPortInit(void){
	//Only PORTD Is LCD Port
	lcdDir=0xFF;
}

void writeCommand(char command){
	
	lcdPort=(command&0xF0)|(1<<E);
	lcdPort=(command&0xF0);
	_delay_us(50);

	lcdPort=(command<<4)|(1<<E);
	lcdPort=(command<<4);
	_delay_ms(3);
}

void writeChararacter(char character){
	
	lcdPort=(character&0xF0)|(1<<E)|(1<<RS);
	lcdPort=(character&0xF0)|(1<<RS);
	_delay_us(50);

	lcdPort=(character<<4)|(1<<E)|(1<<RS);
	lcdPort=(character<<4)|(1<<RS);
	_delay_ms(3);
}

void writeString(char *text){
	while(*text) writeChararacter(*text++);
}

/*This function ease of setting the cursor position*/
void setXy(int x,int y){
	/*Select A 40x4 LCD*/
	char numberOfLines[4]={0x80,0xC0,0x94,0xD4};
	/* The position starts from (x,y)=(0,0) */
	writeCommand(numberOfLines[x]+y);
}

/*ADC Module Setting*/
void adcInit(void){
	/*Select ADC7 To Read LM35*/
	DDRA&=~(1<<7);
	/*Turn On ADC Module ADC Clock Is 1:128*/
	ADCSRA=(1<<ADEN)|(1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0);
	/*Select ADC7 For Analog Input*/
	ADMUX=0x07;
}

float readTemperature(void){
	float temperature;
	/*Begin The ADC Conversion*/
	ADCSRA|=(1<<ADSC);
	/*Wait For Completion*/
	while((ADCSRA&(1<<ADSC))==1);
	temperature=(ADCL+(ADCH<<8))*5.0/1024;
	/*Multiply by 100 to scale up the 1 C/10mV*/
	temperature*=100;
	/*Convert to integer temperature value*/
	return temperature;
}

void lcdInit(void){
/*Initialize the LCD PORT*/
    lcdPortInit();
	/*Writing the instructions
	4-bit mode, 2-line,5x8 dot*/
	writeCommand(0b00110011);
	writeCommand(0b00110010);
	writeCommand(0b00101000);
	writeCommand(0x01);
	/*Turn On Display, Cursor Off*/
	writeCommand(0b00001100);
	/*Cursor Shift in Increment Mode*/
	writeCommand(0b00000110);
}

int main(void)
{	
	char temptxt[16];
	/*LCD degree character*/
	char degree=223;
	float  temperature;
	float  fahrenheit;
	lcdInit();
	adcInit();
	_delay_ms(350);
	
    while (1) {		
		setXy(0,0);
		writeString("Temperature Read");
		setXy(1,0);
		temperature=readTemperature();
		fahrenheit=(temperature*1.8)+32;
		sprintf(temptxt,"%0.1f%cC %0.1f%cF ",temperature,degree,fahrenheit,degree);
		writeString(temptxt);
		
    }
}