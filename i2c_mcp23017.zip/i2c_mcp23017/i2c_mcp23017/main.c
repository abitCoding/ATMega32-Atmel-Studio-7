/*
 * i2c_mcp23017.c
 *
 * Created: 9/9/2020 6:47:16 PM
 * Author : aki-technical
 */ 

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

#define mcp23017Read	0b01000001
#define mcp23017Write	0b01000000

void i2cInit(void){
	TWSR=0x03; //Bit Rate Pre-scaler Is 1:64
	TWBR=0x0F;
	TWCR=(1<<TWEN); //Enable The TWI Module
	PORTC|=(1<<0);
	PORTC|=(1<<1);
}

void i2cStart(void){
	TWCR=(1<<TWINT)|(1<<TWSTA)|(1<<TWEN);
	while((TWCR&(1<<TWINT))==0);
}

void i2cWrite(unsigned char data){
	TWDR=data;
	TWCR=(1<<TWINT)|(1<<TWEN);
	while((TWCR&(1<<TWINT))==0);
}

unsigned char i2cRead(char ACK){
	if(ACK==0)
	TWCR=(1<<TWINT)|(1<<TWEN)|(1<<TWEA);
	else
	TWCR=(1<<TWINT)|(1<<TWEN);
	while((TWCR&(1<<TWINT))==0);
	return TWDR;
}

void i2cStop(){
	TWCR=(1<<TWINT)|(1<<TWEN)|(1<<TWSTO);
}

/*GPIO A and B Direction Control Register*/
const char IODIRA = 0x00;
const char IODIRB = 0x01;
/*GPIOA PULL UP REGISTER CONTROL*/
const char GPPUA  = 0x0C;
/*GPIOA I/O PORT register*/
const char GPIOA  = 0x12;
/*GPIOB Output Register*/
const char OLATB  = 0x15;

/*MCP23017 Configuration Setting*/
void mcp23017Config(char address,char config){
	i2cStart();
	/*Select the write address*/
	i2cWrite(mcp23017Write);
	/*Select a register address*/
	i2cWrite(address);
	/*Send configuration data*/
	i2cWrite(config);
	i2cStop();
}

/*Read Data From MCP23017*/
unsigned char mcp23017Return(char address){
	/*Select a specific address*/
	i2cStart();
	i2cWrite(mcp23017Write);
	i2cWrite(address);
	i2cStop();
	/*Read data from the given address*/
	i2cStart();
	i2cWrite(mcp23017Read);
	unsigned char i2cData=i2cRead(1);
	i2cStop();
	return i2cData;
}
int main(void)
{
	unsigned char i2cData;
	i2cInit();
	/*Pull SCL and SDA high*/
	PORTC=0x03;
	
	/*Set GPIOA To Input*/
	mcp23017Config(IODIRA,0xFF);
	/*Set GPIOB To Output*/
	mcp23017Config(IODIRB,0x00);
	/*Turn On Pull Up Resistors On GPIOB*/
	mcp23017Config(GPPUA,0xFF);

	_delay_ms(10);
	while (1)
	{
		/*Read digital input from GPIOA*/
		i2cData=mcp23017Return(GPIOA);
		/*Send it back to GPIOB*/
		mcp23017Config(OLATB,i2cData);
		_delay_ms(10);
	}
}


