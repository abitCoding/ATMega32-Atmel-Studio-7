/*
 * timer_1_fast_pwm_8_bit_2.c
 *
 * Created: 3/3/2021 8:38:00 PM
 * Author : admin
 */ 

#include <avr/io.h>


int main(void)
{
    /*OC1A and OC1B Output*/
	DDRD=(1<<5)|(1<<4);
	/*inverting fast PWM 8-bit*/
	TCCR1A=(1<<COM1A1)|(1<<COM1B1)|(1<<COM1A0)|(1<<WGM12)|(1<<WGM10);
	/*1::64 Pre-Scaler*/
	TCCR1B=(1<<CS11)|(1<<CS10);
	/*OC1A duty cycle*/
	OCR1AH=0;
	OCR1AL=127;
	/*OC1B duty cycle*/
	OCR1BH=0;
	OCR1BL=75;
    while (1) 
    {
    }
}

