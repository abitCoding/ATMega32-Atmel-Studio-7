/*
 * hd44780_4bit_Example_2.c
 *
 * Created: 8/31/2020 7:06:47 PM
 * Author : aki-technical
 */ 

#include <avr/io.h>
#include <stdio.h>

#define F_CPU 16000000UL
#include <util/delay.h>

#define lcdPort    PORTD
#define lcdDir     DDRD

#define RS	0
#define E	1

void lcdPortInit(void){
	//Only PORTD Is LCD Port
	lcdDir=0xFF;
}

void writeCommand(char command){
	
	lcdPort=(command&0xF0)|(1<<E);
	lcdPort=(command&0xF0);
	_delay_us(50);

	lcdPort=(command<<4)|(1<<E);
	lcdPort=(command<<4);
	_delay_ms(3);
}

void writeChararacter(char character){
	
	lcdPort=(character&0xF0)|(1<<E)|(1<<RS);
	lcdPort=(character&0xF0)|(1<<RS);
	_delay_us(50);

	lcdPort=(character<<4)|(1<<E)|(1<<RS);
	lcdPort=(character<<4)|(1<<RS);
	_delay_ms(3);
}

void writeString(char *text){
	while(*text) writeChararacter(*text++);
}

/*This function ease of setting the cursor position*/
void setXy(int x,int y){
	/*Select A 40x4 LCD*/
	char numberOfLines[4]={0x80,0xC0,0x94,0xD4};
	/* The position starts from (x,y)=(0,0) */
	writeCommand(numberOfLines[x]+y);
}

int main(void)
{	
	char cnt[8];
	char dayCnt=0,secondCnt=0,minuteCnt=0,hourCnt=0;
	/*Initialize the LCD PORT*/
    lcdPortInit();
	/*Writing the instructions
	4-bit mode, 2-line,5x8 dot*/
	writeCommand(0b00110011);
	writeCommand(0b00110010);
	writeCommand(0b00101000);
	writeCommand(0x01);
	/*Turn On Display, Cursor Off*/
	writeCommand(0b00001100);
	/*Cursor Shift in Increment Mode*/
	writeCommand(0b00000110);
	
    while (1) 
    {
		secondCnt++;
		if(secondCnt>=60){
			secondCnt=0;
			minuteCnt++;
		}
		if (minuteCnt>=60)
		{
			minuteCnt=0;
			hourCnt++;
		}
		if (hourCnt>=24)
		{
			hourCnt=0;
			minuteCnt=0;
			secondCnt=0;
		}
		//Convert HH:MM:SS To String
		sprintf(cnt,"%d:%d:%d  ",hourCnt,minuteCnt,secondCnt);
		//Select the upper right
		setXy(0,0);
		/*Writing the time to LCD*/
		writeString("Powered Duration:");
		/*Select Second Line*/
		setXy(1,0);
		writeString(cnt);

		/*Convert days count to string*/
		sprintf(cnt,"%d days",dayCnt);
		/*Select Third Line*/
		setXy(2,0);
		writeString("Days Since Turned On:");
		/*Select Forth Line*/
		setXy(3,0);
		writeString(cnt);
		_delay_ms(1000);
    }
}

