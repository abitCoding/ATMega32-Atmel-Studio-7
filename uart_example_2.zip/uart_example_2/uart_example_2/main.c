/*
 * uart_example_2.c
 *
 * Created: 9/30/2020 5:34:08 PM
 * Author : aki-technical
 */ 

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

#include <string.h>

#define uartReady UCSRA&(1<<RXC)

void uartInit(unsigned long baud){
	unsigned int UBRR;
	/*Baud rate calculator*/
	UBRR=(F_CPU/(16*baud))-1;
	UBRRH=(unsigned char)(UBRR>>8);
	UBRRL=(unsigned char)UBRR;
	/*Enable the transmitter and receiver*/
	UCSRB=(1<<RXEN)|(1<<TXEN)|(1<<RXEN);
	/*asynchronous mode, 8-bit, 1-stop bit*/
	UCSRC=(1<<URSEL)|(1<<UCSZ1)|(1<<UCSZ0);
}

void uartTransmit(unsigned char data){
	/*Stay here until the buffer is empty*/
	while(!(UCSRA&(1<<UDRE)));
	/*Put the data into the buffer*/
	UDR=data;
}

unsigned char uartReceive(void){
	/*Wait until the buffer is full*/
	while(!(UCSRA&(1<<RXC)));
	/*Get the data ready to use*/
	return UDR;
}

void sendText(char *txt){
	while(*txt) uartTransmit(*txt++);
}

char tmp,i=0;
char txt[15];
/*Some string constants to compare with USART command*/
const char cmp1_on[]="rl1On\r",cmp1_off[]="rl1Off\r";
const char cmp2_on[]="rl2On\r",cmp2_off[]="rl2Off\r";
const char cmp3_on[]="rl3On\r",cmp3_off[]="rl3Off\r";
const char cmp4_on[]="rl4On\r",cmp4_off[]="rl4Off\r";
const char allOn[]="allOn\r",allOff[]="allOff\r";

void clearAll(void){
	/*Clear the character storage*/
	tmp='\0';
	/*Clear all the texts*/
	while(i>0){
		txt[i]='\0';
		i--;
	}
}

int main(void)
{
	
	DDRC=0xFF;
	uartInit(9600);
	sendText("ATMEGA32 AVR UART With C String Library Example\r");
	while (1)
	{
		/*If There is a character in the buffer*/
		if (uartReady)
		{
			tmp=uartReceive();
			uartTransmit(tmp);
			txt[i]=tmp;
			i++;
		}
		/*ENTER or new line is 0x0D in hex*/
		if(tmp=='\r'){
		/*Toggling pin PC0*/
			if(strcmp(txt,cmp1_on)==0){
			 PORTC|=(1<<0);
			 sendText("Relay 1 Turns On.\r");
			 }
			else if (strcmp(txt,cmp1_off)==0){
			 PORTC&=~(1<<0);
			 sendText("Relay 1 Turns Off.\r");
			 }
			
		/*Toggling pin PC1*/
			if(strcmp(txt,cmp2_on)==0){
			 PORTC|=(1<<1);
			 sendText("Relay 2 Turns On.\r");
			 }
			else if(strcmp(txt,cmp2_off)==0){
			 PORTC&=~(1<<1);
			 sendText("Relay 2 Turns Off\r");
			 }
			
		/*Toggling pin PC2*/
			if(strcmp(txt,cmp3_on)==0){
			 PORTC|=(1<<2);
			 sendText("Relay 3 Turns On.\r");
			 }
			else if(strcmp(txt,cmp3_off)==0){
			 PORTC&=~(1<<2);
			 sendText("Relay 3 Turns Off\r");
			 }
			
		/*Toggling pin PC3*/
			if(strcmp(txt,cmp4_on)==0){
			 PORTC|=(1<<3);
			 sendText("Relay 4 Turns On.\r");
			 }
			else if(strcmp(txt,cmp4_off)==0){
			 PORTC&=~(1<<3);
			 sendText("Relay 4 Turns Off.\r");
			 }
		/*Overall Controls*/
			if (strcmp(txt,allOn)==0)
			{
				PORTC=0x0F;
				sendText("All relays turn on\r");
			}
			else if (strcmp(txt,allOff)==0)
			{
				PORTC=0x00;
				sendText("All relays turn off\r");
			}
				
		/*Clearing all the data*/
			clearAll();
		}
		
	}
}


