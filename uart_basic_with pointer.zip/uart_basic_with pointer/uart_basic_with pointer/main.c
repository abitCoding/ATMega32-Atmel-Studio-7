/*
 * uart_basic_with pointer.c
 *
 * Created: 9/29/2020 7:05:51 PM
 * Author : aki-technical
 */ 

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

void uartInit(unsigned long baud){
	unsigned int UBRR;
	/*Baud rate calculator*/
	UBRR=(F_CPU/(16*baud))-1;
	UBRRH=(unsigned char)(UBRR>>8);
	UBRRL=(unsigned char)UBRR;
	/*Enable the transmitter and receiver*/
	UCSRB=(1<<RXEN)|(1<<TXEN);
	/*asynchronous mode, 8-bit, 1-stop bit*/
	UCSRC=(1<<URSEL)|(1<<UCSZ1)|(1<<UCSZ0);
}

void uartTransmit(unsigned char data){
	/*Stay here until the buffer is empty*/
	while(!(UCSRA&(1<<UDRE)));
	/*Put the data into the buffer*/
	UDR=data;
}

void sendText(char *txt){
	while(*txt) uartTransmit(*txt++);
}

int main(void)
{
	
	uartInit(9600);
	sendText("Hello From ATMega32 AVR!");
	while (1)
	{
		
	}
}


