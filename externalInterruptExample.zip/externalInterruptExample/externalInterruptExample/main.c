/*
 * externalInterruptExample.c
 *
 * Created: 3/20/2021 4:21:08 PM
 * Author : aki-technical
 */ 

#include <avr/io.h>
#include "avr/interrupt.h"

int main(void)
{
	/*PA7...5 Output*/
	DDRA=(1<<7)|(1<<6)|(1<<5);
	/*INT2 set to high*/
	PORTB=(1<<2);
	/*INT0 and INT1 Set to high*/
	PORTD=(1<<2)|(1<<3);
	/*Turn on external interrupt*/
	GICR=(1<<7)|(1<<6)|(1<<5);
	/*Set Global Interrupt*/
	sei();    
    while (1) 
    {
    }
}

/*Interrupt Service Routine (ISR) for INT0*/
ISR(INT0_vect){
	/*Toggle PA5*/
	PORTA^=(1<<5);
}
/*Interrupt Service Routine (ISR) for INT1*/
ISR(INT1_vect){
	/*Toggle PA6*/
	PORTA^=(1<<6);
}
/*Interrupt Service Routine (ISR) for INT2*/
ISR(INT2_vect){
	/*Toggle PA7*/
	PORTA^=(1<<7);
}