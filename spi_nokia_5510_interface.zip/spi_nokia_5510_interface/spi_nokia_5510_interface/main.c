/*
 * spi_nokia_5510_interface.c
 *
 * Created: 10/1/2020 10:25:23 AM
 * Author : aki-technical
 */ 

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>
#include <stdio.h>
#include "fonts.h"
/*
#define lcdX	48
#define lcdY	84
*/
const unsigned char lcdX = 48;
const unsigned char lcdY = 84;

#define DC  2
#define RST 3
#define selectCommand() PORTB&=~(1<<DC)
#define selectData()	PORTB|=(1<<DC)

void masterInit(void){
	/*Set MOSI, SCK and SS Output*/
	DDRB=(1<<5)|(1<<7)|(1<<4)|(1<<2);
	/*Enable SPI Master set clock rate fck/128*/
	SPCR=(1<<SPE)|(1<<MSTR)|(1<<SPR1)|(1<<SPR0);
}

void masterTransmit(char spiData){
	PORTB&=~(1<<4);
	/*Start the transmission*/
	SPDR=spiData;
	/*Wait for completion*/
	while(!(SPSR&(1<<SPIF)));
	PORTB|=(1<<4);
}

void nokia5510Command(char cmd){
	selectCommand();
	masterTransmit(cmd);
}

void nokia5510Init(void){
	masterInit();
	
	/*Function Set PD=0 And V=0
	Selected Extended Instruction Set 
	H=1 mode*/
	nokia5510Command(0x21);
	/*Set Vop to +16xb[V]*/
	nokia5510Command(0x90);
	/*function set PD=0 and V=0
	Select Norman Instruction Set
	H=0 Mode*/
	nokia5510Command(0x20);
	/*Display Control Set Normal 
	Mode D = 1 and E = 0*/
	nokia5510Command(0x0C);
}

void nokia5510Char(char _char){
	selectData();
	for(char i=0;i<5;i++) {
		masterTransmit(ASCII[_char-0x20][i]);	
	}
	masterTransmit(0x00);
	selectData();
}

void writeText(char *txt){
	while(*txt) nokia5510Char(*txt++);
}

/*Set the cursor*/
void setXy(char x,char y){
	selectCommand();
	/*x ranges from 0 to 83*/
	masterTransmit(0x80+(6*x));
	/*y ranges from 0 to 5*/
	masterTransmit(0x40+y);
	selectCommand();
}

void lcdClear(void){
	for (int i=0;i<lcdX*lcdY/8;i++)
	{
		selectData();
		masterTransmit(0x00);
	}
	selectData();
}

int main(void)
{
	unsigned long secontCnt=0;
	 char cntString[]="";
	nokia5510Init();
	setXy(0,1);
	writeText("ATMega32 SPI");
	setXy(0,2);
	writeText("NOKIA 5510 LCD");
	setXy(0,3);
	writeText("Interfacing");
	setXy(0,4);
	writeText("Example");
	_delay_ms(2000);
	lcdClear();
	setXy(0,0);
	writeText("Started Time:");
	while (1)
	{
		
		sprintf(cntString,"%u",secontCnt);
		setXy(1,2);
		writeText(cntString);
		for(char i=0;i<14;i++) writeText(" ");
		setXy(1,3);
		writeText("Seconds");
		secontCnt++;
		if(secontCnt>=102) secontCnt=0;
		_delay_ms(1000);
		
	}
}


