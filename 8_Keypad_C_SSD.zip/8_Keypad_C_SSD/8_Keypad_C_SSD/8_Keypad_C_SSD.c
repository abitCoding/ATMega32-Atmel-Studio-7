/*
 * _8_Keypad_C_SSD.c
 *
 * Created: 4/24/2018 8:51:03 PM
 *  Author: admin
 */ 


#include <avr/io.h>

#define F_CPU 8000000UL
#include <util/delay.h>

#include "keypad4x4.h"

int main(void)
{	
	DDRD=0xFF;
	PORTD=0x00;
	keyInit();
    while(1)
    {
        //TODO:: Please write your application code 
		PORTD=scan();
		_delay_us(100);
    }
}