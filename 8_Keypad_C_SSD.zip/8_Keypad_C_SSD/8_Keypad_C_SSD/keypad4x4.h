/*
 * keypad4x4.h
 *
 * Created: 4/24/2018 8:52:11 PM
 *  Author: admin
 */ 


#ifndef KEYPAD4X4_H_
#define KEYPAD4X4_H_

#endif /* KEYPAD4X4_H_ */

extern unsigned char scan();
extern void keyInit();