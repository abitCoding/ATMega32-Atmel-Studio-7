/*
 * keypad4x4.c
 *
 * Created: 4/24/2018 8:55:01 PM
 *  Author: admin
 */ 

#include <avr/io.h>
#include "keypad4x4.h"

#define KEY_DATA	PORTC
#define KEY_DIR		DDRC
#define KEY_PIN		PINC

unsigned char keypad[4][4]={{0x07,0x7F,0x6F,0x71},
                            {0x66,0x6D,0x7D,0x79},
                            {0x06,0x5B,0x4F,0x5E},
                            {0x77,0x3F,0x7C,0x39}};	

unsigned char	output[4]={0xFE,0xFD,0xFB,0xF7};
unsigned char	input[4]={0xEF,0xDF,0xBF,0x7F};
unsigned char key_value;

void keyInit(){
	
	KEY_DATA=0xFF;
	KEY_DIR=0x0F;
}

unsigned char scan(){
	
	unsigned char i,j;
	for (i=0;i<4;i++)
	{	
		KEY_DATA=output[i];		
		for (j=0;j<4;j++)
		{		
			KEY_DIR=input[j];
			if ((KEY_PIN&0xF0)!=0xF0)
			{	
				while((KEY_PIN&0xF0)!=0xF0);
				key_value=keypad[j][i];				
				break;
			}
		}
	}
	return key_value;
}