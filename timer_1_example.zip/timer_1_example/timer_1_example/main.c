/*
 * timer_1_example.c
 *
 * Created: 12/19/2020 8:57:35 PM
 * Author : aki-technical
 */ 

#include <avr/io.h>

int main(void)
{
    /*Select Timer Mode, CLK/64*/
	TCCR1B=(1<<CS11)|(1<<CS10);
	/*PC2 Output*/
	DDRC=(1<<2);
	/*Clear Timer Overflow Flag 1*/
	TIFR=(1<<TOV1);
    while (1) 
    {
		/*Check for overflow*/
		if (TIFR&(1<<TOV1))
		{
			/*Clear this flag*/
			TIFR=(1<<TOV1);
			/*Toggle PB2*/
			PORTC^=0x04;
		}
    }
}

