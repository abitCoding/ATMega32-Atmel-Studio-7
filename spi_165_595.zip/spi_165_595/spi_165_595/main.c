/*
 * spi_165_595.c
 *
 * Created: 9/8/2020 7:06:51 PM
 * Author : aki-technical
 */ 

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

void masterInit(void){
	/*Set MOSI, SCK and SS Output*/
	DDRB=(1<<7)|(1<<5)|(1<<4)|(1<<3);
	/*Enable SPI Master set clock rate fck/128
	data samples at falling edge*/
	SPCR=(1<<SPE)|(1<<MSTR)|(1<<SPR1)|(1<<SPR0);
	//SPSR|=(1<<0);	
}

void masterTransmit(char spiData){
	//PORTB&=~(1<<5);
	/*Start the transmission*/
	SPDR=spiData;
	/*Wait for completion*/
	while(!(SPSR&(1<<SPIF)));
	//PORTB&=~(1<<5);
	
}

char masterReceive(void){
	/*Wait for the SPI buffer's full*/
	while(!(SPSR&(1<<SPIF)));
	/*return SPI Buffer*/
	return SPDR;
}

int main(void)
{
	char temp;
	masterInit();

    while (1) 
    {	
		/*Read Digital Data From 74HC165*/
		PORTB=(1<<4);	
		masterTransmit(0x00);
		PORTB&=~(1<<4);
		temp=masterReceive();
		_delay_ms(10);
		
		/*Output Digital Data To 74HC595*/
		PORTB&=~(1<<3);
		masterTransmit(temp);
		PORTB=(1<<3);
		_delay_ms(10);
    }
}


