/*
 * uart_basic.c
 *
 * Created: 9/28/2020 8:19:06 PM
 * Author : aki-technical
 */ 

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

void uartInit(unsigned long baud){
	unsigned int UBRR;
	/*Baud rate calculator*/
	UBRR=(F_CPU/(16*baud))-1;
	UBRRH=(unsigned char)(UBRR>>8);
	UBRRL=(unsigned char)UBRR;
	/*Enable the transmitter and receiver*/
	UCSRB=(1<<RXEN)|(1<<TXEN);
	/*asynchronous mode, 8-bit, 1-stop bit*/
	UCSRC=(1<<URSEL)|(1<<UCSZ1)|(1<<UCSZ0);
}

void uartTransmit(unsigned char data){
	/*Stay here until the buffer is empty*/
	while(!(UCSRA&(1<<UDRE)));
	/*Put the data into the buffer*/
	UDR=data;
}

int main(void)
{
	
    uartInit(9600);
	uartTransmit('H');
	uartTransmit('i');
    while (1) 
    {
		
    }
}

