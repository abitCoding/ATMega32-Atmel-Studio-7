/*
 * hd44780_8bit.c
 *
 * Created: 8/29/2020 7:57:06 AM
 * Author : aki-technical
 */ 

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

#define lcdControl PORTC
#define lcdData    PORTD

#define controlDir DDRC
#define dataDir    DDRD

#define RS	0
#define EN	1

void lcdPortInit(void){
/*PORTC and PORTD Are Output To LCD*/
	controlDir=0xFF;
	dataDir=0xFF;
}

void writeCommand(char command){
	//Set RS to 0
	lcdControl&=~(1<<RS);
	//Set EN to 1 to latch data
	lcdControl|=(1<<EN);
	//Put command into the 8-bit PORT
	lcdData=command;
	//Clear EN to finish
	lcdControl&=~(1<<EN);
	_delay_ms(2);
}

void writeChararacter(char character){
	//Set RS to 1
	lcdControl|=(1<<RS);
	//Set EN to 1 to latch data
	lcdControl|=(1<<EN);
	//Put character into the 8-bit PORT
	lcdData=character;
	//Clear EN to finish
	lcdControl&=~(1<<EN);
	_delay_ms(2);
}
int main(void)
{	
	/*Initialize the LCD PORT*/
    lcdPortInit();
	/*Writing the instructions*/
	writeCommand(0b00110000);
	writeCommand(0b00001110);
	writeCommand(0b00000110);
	/*Writing the Data to the display*/
	writeChararacter('A');
	_delay_ms(2000);
	writeChararacter('.');
	_delay_ms(2000);
	writeChararacter('K');
	_delay_ms(2000);
	writeChararacter('.');
	_delay_ms(2000);
	writeChararacter('I');
    while (1) 
    {
    }
}

