/*
 * i2c_pcf8574.c
 *
 * Created: 9/9/2020 9:10:41 AM
 * Author : aki-technical
 */ 

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

void i2cInit(void){
	TWSR=0x03; //Bit Rate Pre-scaler Is 1:64
	TWBR=0x0F; 
	TWCR=(1<<TWEN); //Enable The TWI Module
	PORTC|=(1<<0);
	PORTC|=(1<<1);
}

void i2cStart(void){
	TWCR=(1<<TWINT)|(1<<TWSTA)|(1<<TWEN);
	while((TWCR&(1<<TWINT))==0);
}

void i2cWrite(unsigned char data){
	TWDR=data;
	TWCR=(1<<TWINT)|(1<<TWEN);
	while((TWCR&(1<<TWINT))==0);
}

unsigned char i2cRead(char ACK){
	if(ACK==0)
	TWCR=(1<<TWINT)|(1<<TWEN)|(1<<TWEA);
	else
	TWCR=(1<<TWINT)|(1<<TWEN);
	while((TWCR&(1<<TWINT))==0);
	return TWDR;
}

void i2cStop(){
	TWCR=(1<<TWINT)|(1<<TWEN)|(1<<TWSTO);
}

int main(void)
{
	unsigned char i2cData=0x00;
	i2cInit();
	PORTC=0x03;

	/*Set the lower nibble high for digital inputs*/
	i2cStart();
	i2cWrite(0x70);
	i2cWrite(0x0F);
	i2cStop();

	while (1)
	{
		
		/*Read the digital inputs*/
		i2cStart();
		i2cWrite(0x71);
		i2cData=i2cRead(1);
		i2cStop();

		/*Transfer the inputs to outputs*/
		i2cData<<=4;

		/*Write inputs to outputs*/
		i2cStart();
		i2cWrite(0x70);
		i2cWrite(i2cData|0x0F);
		i2cStop();

		_delay_ms(10);
	}
}

