/*
 * main.c
 *
 * Created: 8/31/2020 8:57:06 AM
 * Author : aki-technical
 */ 

#include <avr/io.h>

#include <stdio.h>

#define F_CPU 16000000UL
#include <util/delay.h>

#define lcdControl PORTC
#define lcdData    PORTD

#define controlDir DDRC
#define dataDir    DDRD

#define RS	0
#define EN	1

void lcdPortInit(void){
/*PORTC and PORTD Are Output To LCD*/
	controlDir=0xFF;
	dataDir=0xFF;
}

void writeCommand(char command){
	//Set RS to 0
	lcdControl&=~(1<<RS);
	//Set EN to 1 to latch data
	lcdControl|=(1<<EN);
	//Put MSB Of The Command
	lcdData=command;
	//Clear EN to finish
	lcdControl&=~(1<<EN);
	_delay_us(50);

	//Set EN to 1 to latch data
	lcdControl|=(1<<EN);
	//Put LSB Of The Command
	lcdData=command<<4;
	//Clear EN to finish
	lcdControl&=~(1<<EN);
	_delay_ms(3);
}

void writeChararacter(char character){
	//Set RS to 1
	lcdControl|=(1<<RS);
	//Set EN to 1 to latch data
	lcdControl|=(1<<EN);
	//Put MSB Of The Character
	lcdData=character;
	//Clear EN to finish
	lcdControl&=~(1<<EN);
	_delay_us(50);


	//Set EN to 1 to latch data
	lcdControl|=(1<<EN);
	//Put LSB Of The Character
	lcdData=character<<4;
	//Clear EN to finish
	lcdControl&=~(1<<EN);
	_delay_ms(3);
}

void writeString(char *text){
	while(*text) writeChararacter(*text++);
}

/*This function ease of setting the cursor position*/
void setXy(int x,int y){
	char numberOfLines[2]={0x80,0xC0};
	/* The position starts from (x,y)=(0,0) */
	writeCommand(numberOfLines[x]+y);
}

int main(void)
{	
	char cnt[16]="";
	char dayCnt=0,secondCnt=0,minuteCnt=0,hourCnt=0;
	/*Initialize the LCD PORT*/
    lcdPortInit();
	/*Writing the instructions
	4-bit mode, 2-line,5x8 dot*/
	writeCommand(0b00110011);
	writeCommand(0b00110010);
	writeCommand(0b00101000);
	writeCommand(0x01);
	/*Turn On Display, Cursor Off*/
	writeCommand(0b00001100);
	/*Cursor Shift in Increment Mode*/
	writeCommand(0b00000110);
	
    while (1) 
    {
		secondCnt++;
		if(secondCnt>=60){
			secondCnt=0;
			minuteCnt++;
		}
		if (minuteCnt>=60)
		{
			minuteCnt=0;
			hourCnt++;
		}
		if (hourCnt>=24)
		{
			hourCnt=0;
			minuteCnt=0;
			secondCnt=0;
		}
		//Convert timeCnt to String
		sprintf(cnt,"%d days %d:%d:%d  ",dayCnt,hourCnt,minuteCnt,secondCnt);
		//Select the upper right
		setXy(0,0);
		/*Writing the text to the display*/
		writeString("Running Time:");
		/*Select Second Line*/
		setXy(1,0);
		writeString(cnt);
		_delay_ms(1000);
    }
}

