/*
 * uart_Tx_Rx.c
 *
 * Created: 9/29/2020 7:18:40 PM
 * Author : aki-technical
 */ 

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

void uartInit(unsigned long baud){
	unsigned int UBRR;
	/*Baud rate calculator*/
	UBRR=(F_CPU/(16*baud))-1;
	UBRRH=(unsigned char)(UBRR>>8);
	UBRRL=(unsigned char)UBRR;
	/*Enable the transmitter and receiver*/
	UCSRB=(1<<RXEN)|(1<<TXEN)|(1<<RXEN);
	/*asynchronous mode, 8-bit, 1-stop bit*/
	UCSRC=(1<<URSEL)|(1<<UCSZ1)|(1<<UCSZ0);
}

void uartTransmit(unsigned char data){
	/*Stay here until the buffer is empty*/
	while(!(UCSRA&(1<<UDRE)));
	/*Put the data into the buffer*/
	UDR=data;
}

 unsigned char uartReceive(){
	/*Wait until the buffer is full*/
	while(!(UCSRA&(1<<RXC)));
	/*Get the data ready to use*/
	return UDR;
}

void sendText(char *txt){
	while(*txt) uartTransmit(*txt++);
}

int main(void)
{
	char tmp;
	DDRC=0xFF;
	uartInit(9600);
	sendText("ATMEGA32 AVR UART Receive/Transmit Example.\n\r");
	while (1)
	{
		tmp=uartReceive();
		PORTC=tmp;
		uartTransmit(tmp);
	}
}


