/*
 * keypad4x4.h
 *
 * Created: 5/18/2021 10:19:29 PM
 *  Author: admin755
 */ 


#ifndef KEYPAD4X4_H_
#define KEYPAD4X4_H_
#endif /* KEYPAD4X4_H_ */

extern unsigned char scan();
extern void keyInit();