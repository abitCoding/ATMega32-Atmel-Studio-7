/*
 * m32Lcd.c
 *
 * Created: 5/18/2021 10:28:14 PM
 *  Author: admin755
 */ 

#include "m32Lcd.h"



void lcdPortInit(void){
	//Only PORTD Is LCD Port
	lcdDir=0xFF;
}

void writeCommand(char command){
	
	lcdPort=(command&0xF0)|(1<<E);
	lcdPort=(command&0xF0);
	_delay_us(50);

	lcdPort=(command<<4)|(1<<E);
	lcdPort=(command<<4);
	_delay_ms(3);
}

void writeChararacter(char character){
	
	lcdPort=(character&0xF0)|(1<<E)|(1<<RS);
	lcdPort=(character&0xF0)|(1<<RS);
	_delay_us(50);

	lcdPort=(character<<4)|(1<<E)|(1<<RS);
	lcdPort=(character<<4)|(1<<RS);
	_delay_ms(3);
}

void writeString(char *text){
	while(*text) writeChararacter(*text++);
}

/*This function ease of setting the cursor position*/
void setXy(int x,int y){
	/*Select A 40x4 LCD*/
	char numberOfLines[4]={0x80,0xC0,0x94,0xD4};
	/* The position starts from (x,y)=(0,0) */
	writeCommand(numberOfLines[y]+x);
}

void lcdInit(void){
/*Initialize the LCD PORT*/
    lcdPortInit();
	/*Writing the instructions
	4-bit mode, 2-line,5x8 dot*/
	writeCommand(0b00110011);
	writeCommand(0b00110010);
	writeCommand(0b00101000);
	writeCommand(0x01);
	/*Turn On Display, Cursor Off*/
	writeCommand(0b00001100);
	/*Cursor Shift in Increment Mode*/
	writeCommand(0b00000110);
}
