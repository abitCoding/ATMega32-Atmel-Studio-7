/*
 * m32Lcd.h
 *
 * Created: 5/18/2021 10:28:53 PM
 *  Author: admin755
 */ 
#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>

#define lcdPort    PORTD
#define lcdDir     DDRD

#define RS	0
#define E	1

#define  LCD_CLEAR 0x01
#define  CURSOR_ON 0x0F

#ifndef M32LCD_H_
#define M32LCD_H_

#endif /* M32LCD_H_ */

extern void lcdPortInit(void);
extern void writeCommand(char command);
extern void writeChararacter(char character);
extern void writeString(char *text);
/*This function ease of setting the cursor position*/
extern void setXy(int x,int y);
extern void lcdInit(void);


