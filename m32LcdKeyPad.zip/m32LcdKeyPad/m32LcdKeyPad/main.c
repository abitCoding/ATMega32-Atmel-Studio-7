/*
 * m32LcdKeyPad.c
 *
 * Created: 5/18/2021 10:15:15 PM
 * Author : aki-technical
 */ 

#include <avr/io.h>

#define F_CPU 16000000UL
#include <util/delay.h>

#include "keypad4x4.h"
#include "m32Lcd.h"

void writeTitle(void);

unsigned char getKey=0;

int main(void)
{
	unsigned char pressCount=0,newLine=0,lineCount=1;
	DDRD=0xFF;
	PORTD=0x00;
	keyInit();
	lcdInit();
	setXy(0,0);
	writeString("Atmega32 LCD KeyPad");
	setXy(0,1);
	writeString("Interfacing Example");
	setXy(0,2);
	writeString("Programing in C ");
	setXy(0,3);
	writeString("in Atmel Studio 7");
	_delay_ms(2500);
	writeTitle();
	while(1)
	{
		getKey=scan();
		if (getKey!=0)
		{		
			writeChararacter(getKey);
			_delay_ms(250);
			pressCount+=1;
			getKey=0;			
		}
		if (pressCount==20)
		{
			newLine=1;
			lineCount++;
			pressCount=0;
		}
		
		if (newLine)
		{ 
			newLine=0;
			setXy(0,lineCount);
		}
		if (lineCount==4)
		{
			lineCount=1;
			writeTitle();
		}
	}
}

void writeTitle(void){
	/*Clear LCD*/
	writeCommand(LCD_CLEAR);
	setXy(0,0);
	writeString("Enter Key Value: ");
	writeCommand(CURSOR_ON);
	setXy(0,1);
}